import 'package:flutter/material.dart';
import '../../services/task_services.dart';
import '../../models/task_models.dart';
import '../task_list/task_list_page.dart';
import '../task_add/task_add_page.dart';
import '../task_detail/task_detail_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<Task> tasks = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {
    final data = await TaskService.getAllTasks();
    setState(() {
      tasks = data;
      loading = false;
    });
  }

  Widget statusChip(Task task) {
    final status = task.getStatusLabel();
    Color color;
    switch (status) {
      case 'Selesai':
        color = Colors.green;
        break;
      case 'Terlambat':
        color = Colors.red;
        break;
      default:
        color = Colors.blue;
    }
    return Chip(
      label: Text(status, style: const TextStyle(color: Colors.white)),
      backgroundColor: color,
    );
  }

  @override
  Widget build(BuildContext context) {
    final selesai = tasks.where((t) => t.isDone).length;
    final berjalan = tasks.where((t) => !t.isDone).length;

    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Ringkasan Tugas', style: TextStyle(fontSize: 20)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _infoCard('Total Tugas', tasks.length),
                      _infoCard('Selesai', selesai),
                      _infoCard('Berjalan', berjalan),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text('Tugas Terdekat', style: TextStyle(fontWeight: FontWeight.bold)),
                  ...tasks.take(3).map((task) => ListTile(
                        title: Text(task.title),
                        subtitle: Text(task.course),
                        trailing: statusChip(task),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => TaskDetailPage(task: task)),
                          ).then((_) => loadData());
                        },
                      )),
                  const Spacer(),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const TaskListPage()),
                      ).then((_) => loadData());
                    },
                    child: const Text('Lihat Daftar Tugas'),
                  ),
                  OutlinedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const TaskAddPage()),
                      ).then((_) => loadData());
                    },
                    child: const Text('Tambah Tugas'),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _infoCard(String title, int value) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Text(title),
              const SizedBox(height: 8),
              Text(value.toString(), style: const TextStyle(fontSize: 20)),
            ],
          ),
        ),
      ),
    );
  }
}
