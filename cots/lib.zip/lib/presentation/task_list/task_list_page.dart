import 'package:flutter/material.dart';
import '../../services/task_services.dart';
import '../../models/task_models.dart';
import '../task_detail/task_detail_page.dart';
import '../task_add/task_add_page.dart';

class TaskListPage extends StatefulWidget {
  const TaskListPage({super.key});

  @override
  State<TaskListPage> createState() => _TaskListPageState();
}

class _TaskListPageState extends State<TaskListPage> {
  List<Task> tasks = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    fetchTasks();
  }

  Future<void> fetchTasks() async {
    final result = await TaskService.getAllTasks();
    setState(() {
      tasks = result;
      loading = false;
    });
  }

  Widget statusChip(Task task) {
    final status = task.getStatusLabel();
    Color color;
    switch (status) {
      case 'Selesai':
        color = Colors.green;
        break;
      case 'Terlambat':
        color = Colors.red;
        break;
      default:
        color = Colors.blue;
    }
    return Chip(
      label: Text(status, style: const TextStyle(color: Colors.white)),
      backgroundColor: color,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daftar Tugas')),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const TaskAddPage()));
          fetchTasks();
        },
        child: const Icon(Icons.add),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: tasks.length,
              itemBuilder: (context, index) {
                final task = tasks[index];
                return ListTile(
                  title: Text(task.title),
                  subtitle: Text('${task.course} • Deadline ${task.deadline}'),
                  trailing: statusChip(task),
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => TaskDetailPage(task: task)),
                    );
                    fetchTasks();
                  },
                );
              },
            ),
    );
  }
}
