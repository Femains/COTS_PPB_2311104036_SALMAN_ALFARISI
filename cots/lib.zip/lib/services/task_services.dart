import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/task_models.dart';

class TaskService {
  static const String baseUrl = 'https://YOUR_PROJECT_ID.supabase.co/rest/v1';
  static const String apiKey = 'PASTE_ANON_PUBLIC_KEY_DI_SINI';

  static Map<String, String> headers() => {
        'apikey': apiKey,
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      };

  static Future<List<Task>> getAllTasks() async {
    final response = await http.get(
      Uri.parse('$baseUrl/tasks?select=*'),
      headers: headers(),
    );

    if (response.statusCode == 200) {
      final List data = jsonDecode(response.body);
      return data.map((e) => Task.fromJson(e)).toList();
    } else {
      throw Exception('GET gagal: ${response.body}');
    }
  }

  static Future<void> addTask({
    required String title,
    required String course,
    required String deadline,
    required String note,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/tasks'),
      headers: headers(),
      body: jsonEncode({
        'title': title,
        'course': course,
        'deadline': deadline,
        'note': note,
        'is_done': false,
        'status': 'BERJALAN',
      }),
    );

    if (response.statusCode != 201) {
      throw Exception('POST gagal: ${response.body}');
    }
  }

  static Future<void> updateTaskStatus({
    required int id,
    required bool isDone,
  }) async {
    final response = await http.patch(
      Uri.parse('$baseUrl/tasks?id=eq.$id'),
      headers: headers(),
      body: jsonEncode({
        'is_done': isDone,
        'status': isDone ? 'SELESAI' : 'BERJALAN',
      }),
    );

    if (response.statusCode != 200 && response.statusCode != 204) {
      throw Exception('PATCH gagal: ${response.body}');
    }
  }
}
